package com.tns.Student_Service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentService1Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentService1Application.class, args);
	}

}
