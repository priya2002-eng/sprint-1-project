package com.tns.Student_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
